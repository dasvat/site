	
	<footer>
		<div class="footer_wrapper">
			<div class="logo" id="footer_logo">
				<a href="http://Kvar72.ru">
					<img src="/site/wp-content\themes\kvar72\images\log.png"/>
				</a>
			</div>
			<div class="contacts">
				<span><a href="">ГРУППА В ВК</a></span><br>
				<span><a href="">СТРАНИЦА В ВК</a></span><br>
				<span>+7(3452)903-223</span><br>
				<span>+7(932)472-55-62</span>
			</div>
		</div>
	</footer>
	<?php wp_footer(); ?>
	</div>
</body>
</html>